%% **********************************************************************
% Load a mesh
 
clc
close all; clear all;
path = 'head.obj'; 
[V, F] = read_obj(path);   
trisurf(F, V(:, 1), V(:, 2), V(:, 3));
 
nVert = size(V, 1);
nFace = size(F, 1);
 
%% compute the boundary constraint vectors. We need constraints for u and v,
% so the constraints should be stored in a matrix with two column vectors.
[arMat, cotMat] = cotArea(F, V);
cotMat = arMat * cotMat;
[adj, deg] = adjacencyDeg(F);
 
% adj returns 0.5 for boundary edges
bound = adj == 0.5;
adj(bound) = 1;

%% Show boundary vertices
[u, v ,~] = find(bound);
 
color = zeros(size(V, 1), 1);
color(u) = 1;
color(v) = 1;
 
trisurf(F, V(:, 1), V(:, 2), V(:, 3), color, 'FaceColor', 'interp'); hold on;
scatter3(V(:, 1), V(:, 2), V(:, 3), 12 + color*32,  1-color, 'filled'); hold off;

%% Order boundary vertices
[order, dist] = adj2bound(bound, V);

theta = 2*pi;
cons = [zeros(nVert, 1), zeros(nVert, 1)];
cons(order, :) = [cos(theta*dist), sin(theta*dist)];
 
% Compute a Laplacian matrix with uniform weigthts
deg = -deg;
normalUni = (adj + deg) ./ diag(deg);
 
% Compute a Laplacian matrix with cotan weights
normalCot = cotMat ./ diag(cotMat);

% Compute a Laplacian matrix with mean value weights
% Lmeanvalue = 42;
 
%%
% Solve the three different systems and draw the results
normalCot(order, :) = zeros(length(order), nVert);
normalCot(sub2ind(size(normalCot), order, order)) = 1;
% M(order, :) = cons(order, :);

cotU = normalCot \ cons(:, 1);
cotW = normalCot \ cons(:, 2);

%
normalUni(order, :) = zeros(length(order), nVert);
normalUni(sub2ind(size(normalCot), order, order)) = 1;
% M(order, :) = cons(order, :);

uniU = normalUni \ cons(:, 1);
uniW = normalUni \ cons(:, 2);
 
%%
% Save out the results as png files
figure()
viscircles([0, 0], 1); hold on
trisurf(F, cotU, cotW, zeros(nVert, 1), color, 'FaceColor', 'interp');

figure()
viscircles([0, 0], 1); hold on
trisurf(F, uniU, uniW, zeros(nVert, 1), color, 'FaceColor', 'interp');